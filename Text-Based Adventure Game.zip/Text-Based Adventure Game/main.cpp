#include <iostream>
#include <string>

using namespace std;

int main() {
    string playerName;
    int choice;

    cout << "Welcome to the Text Adventure Game!" << endl;
    cout << "Please enter your name: ";
    cin >> playerName;

    cout << endl;
    cout << "Hello, " << playerName << "! You find yourself in a mysterious forest." << endl;
    cout << "You see two paths ahead of you. What would you like to do?" << endl;
    cout << "1. Take the left path." << endl;
    cout << "2. Take the right path." << endl;

    cin >> choice;

    if (choice == 1) {
        cout << "You chose the left path." << endl;
        cout << "As you walk along the path, you come across a river." << endl;
        cout << "What would you like to do?" << endl;
        cout << "1. Try to swim across the river." << endl;
        cout << "2. Look for a bridge." << endl;

        cin >> choice;

        if (choice == 1) {
            cout << "You try to swim across the river but are swept away by the current." << endl;
            cout << "Game Over!" << endl;
        } else if (choice == 2) {
            cout << "You find a sturdy bridge and cross the river safely." << endl;
            cout << "You continue on your journey." << endl;
        }
    } else if (choice == 2) {
        cout << "You chose the right path." << endl;
        cout << "You walk for a while and discover a hidden treasure chest." << endl;
        cout << "What would you like to do?" << endl;
        cout << "1. Open the treasure chest." << endl;
        cout << "2. Leave it alone." << endl;

        cin >> choice;

        if (choice == 1) {
            cout << "As you open the treasure chest, a trap is triggered, and spikes come out, injuring you." << endl;
            cout << "Game Over!" << endl;
        } else if (choice == 2) {
            cout << "You decide not to mess with the chest and continue exploring." << endl;
            cout << "You hear strange noises in the distance." << endl;
        }
    }

    cout << "You've survived the adventure, " << playerName << "! Thanks for playing." << endl;

    return 0;
}
